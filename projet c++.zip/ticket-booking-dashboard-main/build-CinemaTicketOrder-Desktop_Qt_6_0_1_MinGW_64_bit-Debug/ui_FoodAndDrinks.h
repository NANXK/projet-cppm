/********************************************************************************
** Form generated from reading UI file 'FoodAndDrinks.ui'
**
** Created by: Qt User Interface Compiler version 6.0.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_FOODANDDRINKS_H
#define UI_FOODANDDRINKS_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QTableWidget>
#include <QtWidgets/QVBoxLayout>

QT_BEGIN_NAMESPACE

class Ui_FoodAndDrinks
{
public:
    QHBoxLayout *horizontalLayout_10;
    QVBoxLayout *verticalLayout;
    QGroupBox *groupBox;
    QHBoxLayout *horizontalLayout_4;
    QVBoxLayout *verticalLayout_4;
    QLabel *label_3;
    QLabel *label_4;
    QPushButton *pushButton_traditional;
    QVBoxLayout *verticalLayout_6;
    QLabel *label_7;
    QLabel *label_8;
    QPushButton *pushButton_kidsPacks;
    QGroupBox *groupBox_2;
    QHBoxLayout *horizontalLayout;
    QVBoxLayout *verticalLayout_17;
    QLabel *label_29;
    QLabel *label_30;
    QPushButton *pushButton_coke;
    QVBoxLayout *verticalLayout_22;
    QLabel *label_39;
    QLabel *label_40;
    QPushButton *pushButton_ICEE;
    QVBoxLayout *verticalLayout_23;
    QLabel *label_41;
    QLabel *label_42;
    QPushButton *pushButton_bottledDrinks;
    QVBoxLayout *verticalLayout_24;
    QLabel *label_43;
    QLabel *label_44;
    QPushButton *pushButton_costaCoffee;
    QGroupBox *groupBox_3;
    QHBoxLayout *horizontalLayout_5;
    QVBoxLayout *verticalLayout_11;
    QLabel *label_17;
    QLabel *label_18;
    QPushButton *pushButton_chickenTenders;
    QVBoxLayout *verticalLayout_12;
    QLabel *label_19;
    QLabel *label_20;
    QPushButton *pushButton_curlyFries;
    QGroupBox *groupBox_4;
    QHBoxLayout *horizontalLayout_6;
    QVBoxLayout *verticalLayout_13;
    QLabel *label_21;
    QLabel *label_22;
    QPushButton *pushButton_iceCream;
    QVBoxLayout *verticalLayout_14;
    QLabel *label_23;
    QLabel *label_24;
    QPushButton *pushButton_glutenFreeSnacks;
    QVBoxLayout *verticalLayout_15;
    QLabel *label_25;
    QLabel *label_26;
    QPushButton *pushButton_candy;
    QGroupBox *groupBox_5;
    QHBoxLayout *horizontalLayout_8;
    QVBoxLayout *verticalLayout_18;
    QLabel *label_31;
    QLabel *label_32;
    QPushButton *pushButton_wonderWoman;
    QGroupBox *groupBox_6;
    QHBoxLayout *horizontalLayout_7;
    QVBoxLayout *verticalLayout_19;
    QLabel *label_33;
    QLabel *label_34;
    QPushButton *pushButton_cameoPartyPack;
    QVBoxLayout *verticalLayout_20;
    QLabel *label_35;
    QLabel *label_36;
    QPushButton *pushButton_kidsPartyPack;
    QVBoxLayout *verticalLayout_21;
    QLabel *label_37;
    QLabel *label_38;
    QPushButton *pushButton_tendersFriesPack;
    QVBoxLayout *verticalLayout_3;
    QTableWidget *tableWidget;
    QVBoxLayout *verticalLayout_2;
    QHBoxLayout *horizontalLayout_2;
    QSpacerItem *horizontalSpacer_2;
    QLabel *label;
    QLabel *label_foodCost;
    QHBoxLayout *horizontalLayout_3;
    QSpacerItem *horizontalSpacer;
    QPushButton *pushButton_clearAll;
    QPushButton *pushButton_checkOut;

    void setupUi(QDialog *FoodAndDrinks)
    {
        if (FoodAndDrinks->objectName().isEmpty())
            FoodAndDrinks->setObjectName(QString::fromUtf8("FoodAndDrinks"));
        FoodAndDrinks->resize(1024, 656);
        horizontalLayout_10 = new QHBoxLayout(FoodAndDrinks);
        horizontalLayout_10->setObjectName(QString::fromUtf8("horizontalLayout_10"));
        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        verticalLayout->setSizeConstraint(QLayout::SetFixedSize);
        groupBox = new QGroupBox(FoodAndDrinks);
        groupBox->setObjectName(QString::fromUtf8("groupBox"));
        horizontalLayout_4 = new QHBoxLayout(groupBox);
        horizontalLayout_4->setObjectName(QString::fromUtf8("horizontalLayout_4"));
        verticalLayout_4 = new QVBoxLayout();
        verticalLayout_4->setObjectName(QString::fromUtf8("verticalLayout_4"));
        label_3 = new QLabel(groupBox);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        verticalLayout_4->addWidget(label_3);

        label_4 = new QLabel(groupBox);
        label_4->setObjectName(QString::fromUtf8("label_4"));

        verticalLayout_4->addWidget(label_4);

        pushButton_traditional = new QPushButton(groupBox);
        pushButton_traditional->setObjectName(QString::fromUtf8("pushButton_traditional"));

        verticalLayout_4->addWidget(pushButton_traditional);


        horizontalLayout_4->addLayout(verticalLayout_4);

        verticalLayout_6 = new QVBoxLayout();
        verticalLayout_6->setObjectName(QString::fromUtf8("verticalLayout_6"));
        label_7 = new QLabel(groupBox);
        label_7->setObjectName(QString::fromUtf8("label_7"));

        verticalLayout_6->addWidget(label_7);

        label_8 = new QLabel(groupBox);
        label_8->setObjectName(QString::fromUtf8("label_8"));

        verticalLayout_6->addWidget(label_8);

        pushButton_kidsPacks = new QPushButton(groupBox);
        pushButton_kidsPacks->setObjectName(QString::fromUtf8("pushButton_kidsPacks"));

        verticalLayout_6->addWidget(pushButton_kidsPacks);


        horizontalLayout_4->addLayout(verticalLayout_6);


        verticalLayout->addWidget(groupBox);

        groupBox_2 = new QGroupBox(FoodAndDrinks);
        groupBox_2->setObjectName(QString::fromUtf8("groupBox_2"));
        horizontalLayout = new QHBoxLayout(groupBox_2);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        verticalLayout_17 = new QVBoxLayout();
        verticalLayout_17->setObjectName(QString::fromUtf8("verticalLayout_17"));
        label_29 = new QLabel(groupBox_2);
        label_29->setObjectName(QString::fromUtf8("label_29"));

        verticalLayout_17->addWidget(label_29);

        label_30 = new QLabel(groupBox_2);
        label_30->setObjectName(QString::fromUtf8("label_30"));

        verticalLayout_17->addWidget(label_30);

        pushButton_coke = new QPushButton(groupBox_2);
        pushButton_coke->setObjectName(QString::fromUtf8("pushButton_coke"));

        verticalLayout_17->addWidget(pushButton_coke);


        horizontalLayout->addLayout(verticalLayout_17);

        verticalLayout_22 = new QVBoxLayout();
        verticalLayout_22->setObjectName(QString::fromUtf8("verticalLayout_22"));
        label_39 = new QLabel(groupBox_2);
        label_39->setObjectName(QString::fromUtf8("label_39"));

        verticalLayout_22->addWidget(label_39);

        label_40 = new QLabel(groupBox_2);
        label_40->setObjectName(QString::fromUtf8("label_40"));

        verticalLayout_22->addWidget(label_40);

        pushButton_ICEE = new QPushButton(groupBox_2);
        pushButton_ICEE->setObjectName(QString::fromUtf8("pushButton_ICEE"));

        verticalLayout_22->addWidget(pushButton_ICEE);


        horizontalLayout->addLayout(verticalLayout_22);

        verticalLayout_23 = new QVBoxLayout();
        verticalLayout_23->setObjectName(QString::fromUtf8("verticalLayout_23"));
        label_41 = new QLabel(groupBox_2);
        label_41->setObjectName(QString::fromUtf8("label_41"));

        verticalLayout_23->addWidget(label_41);

        label_42 = new QLabel(groupBox_2);
        label_42->setObjectName(QString::fromUtf8("label_42"));

        verticalLayout_23->addWidget(label_42);

        pushButton_bottledDrinks = new QPushButton(groupBox_2);
        pushButton_bottledDrinks->setObjectName(QString::fromUtf8("pushButton_bottledDrinks"));

        verticalLayout_23->addWidget(pushButton_bottledDrinks);


        horizontalLayout->addLayout(verticalLayout_23);

        verticalLayout_24 = new QVBoxLayout();
        verticalLayout_24->setObjectName(QString::fromUtf8("verticalLayout_24"));
        label_43 = new QLabel(groupBox_2);
        label_43->setObjectName(QString::fromUtf8("label_43"));

        verticalLayout_24->addWidget(label_43);

        label_44 = new QLabel(groupBox_2);
        label_44->setObjectName(QString::fromUtf8("label_44"));

        verticalLayout_24->addWidget(label_44);

        pushButton_costaCoffee = new QPushButton(groupBox_2);
        pushButton_costaCoffee->setObjectName(QString::fromUtf8("pushButton_costaCoffee"));

        verticalLayout_24->addWidget(pushButton_costaCoffee);


        horizontalLayout->addLayout(verticalLayout_24);


        verticalLayout->addWidget(groupBox_2);

        groupBox_3 = new QGroupBox(FoodAndDrinks);
        groupBox_3->setObjectName(QString::fromUtf8("groupBox_3"));
        horizontalLayout_5 = new QHBoxLayout(groupBox_3);
        horizontalLayout_5->setObjectName(QString::fromUtf8("horizontalLayout_5"));
        verticalLayout_11 = new QVBoxLayout();
        verticalLayout_11->setObjectName(QString::fromUtf8("verticalLayout_11"));
        label_17 = new QLabel(groupBox_3);
        label_17->setObjectName(QString::fromUtf8("label_17"));

        verticalLayout_11->addWidget(label_17);

        label_18 = new QLabel(groupBox_3);
        label_18->setObjectName(QString::fromUtf8("label_18"));

        verticalLayout_11->addWidget(label_18);

        pushButton_chickenTenders = new QPushButton(groupBox_3);
        pushButton_chickenTenders->setObjectName(QString::fromUtf8("pushButton_chickenTenders"));

        verticalLayout_11->addWidget(pushButton_chickenTenders);


        horizontalLayout_5->addLayout(verticalLayout_11);

        verticalLayout_12 = new QVBoxLayout();
        verticalLayout_12->setObjectName(QString::fromUtf8("verticalLayout_12"));
        label_19 = new QLabel(groupBox_3);
        label_19->setObjectName(QString::fromUtf8("label_19"));

        verticalLayout_12->addWidget(label_19);

        label_20 = new QLabel(groupBox_3);
        label_20->setObjectName(QString::fromUtf8("label_20"));

        verticalLayout_12->addWidget(label_20);

        pushButton_curlyFries = new QPushButton(groupBox_3);
        pushButton_curlyFries->setObjectName(QString::fromUtf8("pushButton_curlyFries"));

        verticalLayout_12->addWidget(pushButton_curlyFries);


        horizontalLayout_5->addLayout(verticalLayout_12);


        verticalLayout->addWidget(groupBox_3);

        groupBox_4 = new QGroupBox(FoodAndDrinks);
        groupBox_4->setObjectName(QString::fromUtf8("groupBox_4"));
        horizontalLayout_6 = new QHBoxLayout(groupBox_4);
        horizontalLayout_6->setObjectName(QString::fromUtf8("horizontalLayout_6"));
        verticalLayout_13 = new QVBoxLayout();
        verticalLayout_13->setObjectName(QString::fromUtf8("verticalLayout_13"));
        label_21 = new QLabel(groupBox_4);
        label_21->setObjectName(QString::fromUtf8("label_21"));

        verticalLayout_13->addWidget(label_21);

        label_22 = new QLabel(groupBox_4);
        label_22->setObjectName(QString::fromUtf8("label_22"));

        verticalLayout_13->addWidget(label_22);

        pushButton_iceCream = new QPushButton(groupBox_4);
        pushButton_iceCream->setObjectName(QString::fromUtf8("pushButton_iceCream"));

        verticalLayout_13->addWidget(pushButton_iceCream);


        horizontalLayout_6->addLayout(verticalLayout_13);

        verticalLayout_14 = new QVBoxLayout();
        verticalLayout_14->setObjectName(QString::fromUtf8("verticalLayout_14"));
        label_23 = new QLabel(groupBox_4);
        label_23->setObjectName(QString::fromUtf8("label_23"));

        verticalLayout_14->addWidget(label_23);

        label_24 = new QLabel(groupBox_4);
        label_24->setObjectName(QString::fromUtf8("label_24"));

        verticalLayout_14->addWidget(label_24);

        pushButton_glutenFreeSnacks = new QPushButton(groupBox_4);
        pushButton_glutenFreeSnacks->setObjectName(QString::fromUtf8("pushButton_glutenFreeSnacks"));

        verticalLayout_14->addWidget(pushButton_glutenFreeSnacks);


        horizontalLayout_6->addLayout(verticalLayout_14);

        verticalLayout_15 = new QVBoxLayout();
        verticalLayout_15->setObjectName(QString::fromUtf8("verticalLayout_15"));
        label_25 = new QLabel(groupBox_4);
        label_25->setObjectName(QString::fromUtf8("label_25"));

        verticalLayout_15->addWidget(label_25);

        label_26 = new QLabel(groupBox_4);
        label_26->setObjectName(QString::fromUtf8("label_26"));

        verticalLayout_15->addWidget(label_26);

        pushButton_candy = new QPushButton(groupBox_4);
        pushButton_candy->setObjectName(QString::fromUtf8("pushButton_candy"));

        verticalLayout_15->addWidget(pushButton_candy);


        horizontalLayout_6->addLayout(verticalLayout_15);


        verticalLayout->addWidget(groupBox_4);

        groupBox_5 = new QGroupBox(FoodAndDrinks);
        groupBox_5->setObjectName(QString::fromUtf8("groupBox_5"));
        horizontalLayout_8 = new QHBoxLayout(groupBox_5);
        horizontalLayout_8->setObjectName(QString::fromUtf8("horizontalLayout_8"));
        verticalLayout_18 = new QVBoxLayout();
        verticalLayout_18->setObjectName(QString::fromUtf8("verticalLayout_18"));
        label_31 = new QLabel(groupBox_5);
        label_31->setObjectName(QString::fromUtf8("label_31"));

        verticalLayout_18->addWidget(label_31);

        label_32 = new QLabel(groupBox_5);
        label_32->setObjectName(QString::fromUtf8("label_32"));

        verticalLayout_18->addWidget(label_32);

        pushButton_wonderWoman = new QPushButton(groupBox_5);
        pushButton_wonderWoman->setObjectName(QString::fromUtf8("pushButton_wonderWoman"));

        verticalLayout_18->addWidget(pushButton_wonderWoman);


        horizontalLayout_8->addLayout(verticalLayout_18);


        verticalLayout->addWidget(groupBox_5);

        groupBox_6 = new QGroupBox(FoodAndDrinks);
        groupBox_6->setObjectName(QString::fromUtf8("groupBox_6"));
        horizontalLayout_7 = new QHBoxLayout(groupBox_6);
        horizontalLayout_7->setObjectName(QString::fromUtf8("horizontalLayout_7"));
        verticalLayout_19 = new QVBoxLayout();
        verticalLayout_19->setObjectName(QString::fromUtf8("verticalLayout_19"));
        label_33 = new QLabel(groupBox_6);
        label_33->setObjectName(QString::fromUtf8("label_33"));

        verticalLayout_19->addWidget(label_33);

        label_34 = new QLabel(groupBox_6);
        label_34->setObjectName(QString::fromUtf8("label_34"));

        verticalLayout_19->addWidget(label_34);

        pushButton_cameoPartyPack = new QPushButton(groupBox_6);
        pushButton_cameoPartyPack->setObjectName(QString::fromUtf8("pushButton_cameoPartyPack"));

        verticalLayout_19->addWidget(pushButton_cameoPartyPack);


        horizontalLayout_7->addLayout(verticalLayout_19);

        verticalLayout_20 = new QVBoxLayout();
        verticalLayout_20->setObjectName(QString::fromUtf8("verticalLayout_20"));
        label_35 = new QLabel(groupBox_6);
        label_35->setObjectName(QString::fromUtf8("label_35"));

        verticalLayout_20->addWidget(label_35);

        label_36 = new QLabel(groupBox_6);
        label_36->setObjectName(QString::fromUtf8("label_36"));

        verticalLayout_20->addWidget(label_36);

        pushButton_kidsPartyPack = new QPushButton(groupBox_6);
        pushButton_kidsPartyPack->setObjectName(QString::fromUtf8("pushButton_kidsPartyPack"));

        verticalLayout_20->addWidget(pushButton_kidsPartyPack);


        horizontalLayout_7->addLayout(verticalLayout_20);

        verticalLayout_21 = new QVBoxLayout();
        verticalLayout_21->setObjectName(QString::fromUtf8("verticalLayout_21"));
        label_37 = new QLabel(groupBox_6);
        label_37->setObjectName(QString::fromUtf8("label_37"));

        verticalLayout_21->addWidget(label_37);

        label_38 = new QLabel(groupBox_6);
        label_38->setObjectName(QString::fromUtf8("label_38"));

        verticalLayout_21->addWidget(label_38);

        pushButton_tendersFriesPack = new QPushButton(groupBox_6);
        pushButton_tendersFriesPack->setObjectName(QString::fromUtf8("pushButton_tendersFriesPack"));

        verticalLayout_21->addWidget(pushButton_tendersFriesPack);


        horizontalLayout_7->addLayout(verticalLayout_21);


        verticalLayout->addWidget(groupBox_6);


        horizontalLayout_10->addLayout(verticalLayout);

        verticalLayout_3 = new QVBoxLayout();
        verticalLayout_3->setObjectName(QString::fromUtf8("verticalLayout_3"));
        tableWidget = new QTableWidget(FoodAndDrinks);
        if (tableWidget->columnCount() < 2)
            tableWidget->setColumnCount(2);
        QTableWidgetItem *__qtablewidgetitem = new QTableWidgetItem();
        __qtablewidgetitem->setTextAlignment(Qt::AlignCenter);
        tableWidget->setHorizontalHeaderItem(0, __qtablewidgetitem);
        QTableWidgetItem *__qtablewidgetitem1 = new QTableWidgetItem();
        tableWidget->setHorizontalHeaderItem(1, __qtablewidgetitem1);
        tableWidget->setObjectName(QString::fromUtf8("tableWidget"));
        tableWidget->horizontalHeader()->setCascadingSectionResizes(false);
        tableWidget->horizontalHeader()->setDefaultSectionSize(200);
        tableWidget->horizontalHeader()->setStretchLastSection(true);
        tableWidget->verticalHeader()->setStretchLastSection(false);

        verticalLayout_3->addWidget(tableWidget);

        verticalLayout_2 = new QVBoxLayout();
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        horizontalSpacer_2 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer_2);

        label = new QLabel(FoodAndDrinks);
        label->setObjectName(QString::fromUtf8("label"));

        horizontalLayout_2->addWidget(label);

        label_foodCost = new QLabel(FoodAndDrinks);
        label_foodCost->setObjectName(QString::fromUtf8("label_foodCost"));

        horizontalLayout_2->addWidget(label_foodCost);


        verticalLayout_2->addLayout(horizontalLayout_2);


        verticalLayout_3->addLayout(verticalLayout_2);

        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_3->addItem(horizontalSpacer);

        pushButton_clearAll = new QPushButton(FoodAndDrinks);
        pushButton_clearAll->setObjectName(QString::fromUtf8("pushButton_clearAll"));

        horizontalLayout_3->addWidget(pushButton_clearAll);

        pushButton_checkOut = new QPushButton(FoodAndDrinks);
        pushButton_checkOut->setObjectName(QString::fromUtf8("pushButton_checkOut"));

        horizontalLayout_3->addWidget(pushButton_checkOut);


        verticalLayout_3->addLayout(horizontalLayout_3);


        horizontalLayout_10->addLayout(verticalLayout_3);


        retranslateUi(FoodAndDrinks);

        QMetaObject::connectSlotsByName(FoodAndDrinks);
    } // setupUi

    void retranslateUi(QDialog *FoodAndDrinks)
    {
        FoodAndDrinks->setWindowTitle(QCoreApplication::translate("FoodAndDrinks", "Food & Drinks", nullptr));
        groupBox->setTitle(QCoreApplication::translate("FoodAndDrinks", "Popcorn", nullptr));
        label_3->setText(QCoreApplication::translate("FoodAndDrinks", "Traditional", nullptr));
        label_4->setText(QCoreApplication::translate("FoodAndDrinks", "$8.79", nullptr));
        pushButton_traditional->setText(QCoreApplication::translate("FoodAndDrinks", "Select", nullptr));
        label_7->setText(QCoreApplication::translate("FoodAndDrinks", "Kids Pack", nullptr));
        label_8->setText(QCoreApplication::translate("FoodAndDrinks", "$7.09", nullptr));
        pushButton_kidsPacks->setText(QCoreApplication::translate("FoodAndDrinks", "Select", nullptr));
        groupBox_2->setTitle(QCoreApplication::translate("FoodAndDrinks", "Beverages", nullptr));
        label_29->setText(QCoreApplication::translate("FoodAndDrinks", "Coke", nullptr));
        label_30->setText(QCoreApplication::translate("FoodAndDrinks", "$6.49", nullptr));
        pushButton_coke->setText(QCoreApplication::translate("FoodAndDrinks", "Select", nullptr));
        label_39->setText(QCoreApplication::translate("FoodAndDrinks", "ICEE", nullptr));
        label_40->setText(QCoreApplication::translate("FoodAndDrinks", "$6.99", nullptr));
        pushButton_ICEE->setText(QCoreApplication::translate("FoodAndDrinks", "Select", nullptr));
        label_41->setText(QCoreApplication::translate("FoodAndDrinks", "Bottled Drinks", nullptr));
        label_42->setText(QCoreApplication::translate("FoodAndDrinks", "$4.99", nullptr));
        pushButton_bottledDrinks->setText(QCoreApplication::translate("FoodAndDrinks", "Select", nullptr));
        label_43->setText(QCoreApplication::translate("FoodAndDrinks", "Costa Coffee", nullptr));
        label_44->setText(QCoreApplication::translate("FoodAndDrinks", "$1.00", nullptr));
        pushButton_costaCoffee->setText(QCoreApplication::translate("FoodAndDrinks", "Select", nullptr));
        groupBox_3->setTitle(QCoreApplication::translate("FoodAndDrinks", "Snacks", nullptr));
        label_17->setText(QCoreApplication::translate("FoodAndDrinks", "Chicken Tenders", nullptr));
        label_18->setText(QCoreApplication::translate("FoodAndDrinks", "$8.29", nullptr));
        pushButton_chickenTenders->setText(QCoreApplication::translate("FoodAndDrinks", "Select", nullptr));
        label_19->setText(QCoreApplication::translate("FoodAndDrinks", "Curly Fries", nullptr));
        label_20->setText(QCoreApplication::translate("FoodAndDrinks", "$5.99", nullptr));
        pushButton_curlyFries->setText(QCoreApplication::translate("FoodAndDrinks", "Select", nullptr));
        groupBox_4->setTitle(QCoreApplication::translate("FoodAndDrinks", "Treats", nullptr));
        label_21->setText(QCoreApplication::translate("FoodAndDrinks", "Ice Cream", nullptr));
        label_22->setText(QCoreApplication::translate("FoodAndDrinks", "$4.69", nullptr));
        pushButton_iceCream->setText(QCoreApplication::translate("FoodAndDrinks", "Select", nullptr));
        label_23->setText(QCoreApplication::translate("FoodAndDrinks", "Gluten Free Snacks", nullptr));
        label_24->setText(QCoreApplication::translate("FoodAndDrinks", "$6.29", nullptr));
        pushButton_glutenFreeSnacks->setText(QCoreApplication::translate("FoodAndDrinks", "Select", nullptr));
        label_25->setText(QCoreApplication::translate("FoodAndDrinks", "Candy", nullptr));
        label_26->setText(QCoreApplication::translate("FoodAndDrinks", "$4.89", nullptr));
        pushButton_candy->setText(QCoreApplication::translate("FoodAndDrinks", "Select", nullptr));
        groupBox_5->setTitle(QCoreApplication::translate("FoodAndDrinks", "Special Offers", nullptr));
        label_31->setText(QCoreApplication::translate("FoodAndDrinks", "Wonder Woman 1984", nullptr));
        label_32->setText(QCoreApplication::translate("FoodAndDrinks", "$11.99", nullptr));
        pushButton_wonderWoman->setText(QCoreApplication::translate("FoodAndDrinks", "Select", nullptr));
        groupBox_6->setTitle(QCoreApplication::translate("FoodAndDrinks", "Party Packs", nullptr));
        label_33->setText(QCoreApplication::translate("FoodAndDrinks", "Cameo Party Pack", nullptr));
        label_34->setText(QCoreApplication::translate("FoodAndDrinks", "$79.99", nullptr));
        pushButton_cameoPartyPack->setText(QCoreApplication::translate("FoodAndDrinks", "Select", nullptr));
        label_35->setText(QCoreApplication::translate("FoodAndDrinks", "Kids Party Pack", nullptr));
        label_36->setText(QCoreApplication::translate("FoodAndDrinks", "$49.99", nullptr));
        pushButton_kidsPartyPack->setText(QCoreApplication::translate("FoodAndDrinks", "Select", nullptr));
        label_37->setText(QCoreApplication::translate("FoodAndDrinks", "Tenders & Fries Pack", nullptr));
        label_38->setText(QCoreApplication::translate("FoodAndDrinks", "$79.99", nullptr));
        pushButton_tendersFriesPack->setText(QCoreApplication::translate("FoodAndDrinks", "Select", nullptr));
        QTableWidgetItem *___qtablewidgetitem = tableWidget->horizontalHeaderItem(0);
        ___qtablewidgetitem->setText(QCoreApplication::translate("FoodAndDrinks", "Item", nullptr));
        QTableWidgetItem *___qtablewidgetitem1 = tableWidget->horizontalHeaderItem(1);
        ___qtablewidgetitem1->setText(QCoreApplication::translate("FoodAndDrinks", "Price", nullptr));
        label->setText(QCoreApplication::translate("FoodAndDrinks", "Total:", nullptr));
        label_foodCost->setText(QCoreApplication::translate("FoodAndDrinks", "<html><head/><body><p><span style=\" font-weight:600;\">$33.50</span></p></body></html>", nullptr));
        pushButton_clearAll->setText(QCoreApplication::translate("FoodAndDrinks", "Clear All", nullptr));
        pushButton_checkOut->setText(QCoreApplication::translate("FoodAndDrinks", "Check out", nullptr));
    } // retranslateUi

};

namespace Ui {
    class FoodAndDrinks: public Ui_FoodAndDrinks {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_FOODANDDRINKS_H
