/********************************************************************************
** Form generated from reading UI file 'SeatAvailability.ui'
**
** Created by: Qt User Interface Compiler version 6.0.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SEATAVAILABILITY_H
#define UI_SEATAVAILABILITY_H

#include <QtCore/QLocale>
#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QVBoxLayout>

QT_BEGIN_NAMESPACE

class Ui_SeatAvailability
{
public:
    QVBoxLayout *verticalLayout;
    QLabel *label_screen;
    QSpacerItem *verticalSpacer;
    QVBoxLayout *verticalLayout_allRows;
    QHBoxLayout *horizontalLayout_rowA;
    QPushButton *pushButton_A1;
    QPushButton *pushButton_A2;
    QPushButton *pushButton_A3;
    QPushButton *pushButton_A4;
    QPushButton *pushButton_A5;
    QPushButton *pushButton_A6;
    QPushButton *pushButton_A7;
    QPushButton *pushButton_A8;
    QPushButton *pushButton_A9;
    QPushButton *pushButton_A10;
    QPushButton *pushButton_A11;
    QPushButton *pushButton_A12;
    QHBoxLayout *horizontalLayout_rowB;
    QPushButton *pushButton_B1;
    QPushButton *pushButton_B2;
    QPushButton *pushButton_B3;
    QPushButton *pushButton_B4;
    QPushButton *pushButton_B5;
    QPushButton *pushButton_B6;
    QPushButton *pushButton_B7;
    QPushButton *pushButton_B8;
    QPushButton *pushButton_B9;
    QPushButton *pushButton_B10;
    QPushButton *pushButton_B11;
    QPushButton *pushButton_B12;
    QHBoxLayout *horizontalLayout_rowC;
    QPushButton *pushButton_C1;
    QPushButton *pushButton_C2;
    QPushButton *pushButton_C3;
    QPushButton *pushButton_C4;
    QPushButton *pushButton_C5;
    QPushButton *pushButton_C6;
    QPushButton *pushButton_C7;
    QPushButton *pushButton_C8;
    QPushButton *pushButton_C9;
    QPushButton *pushButton_C10;
    QPushButton *pushButton_C11;
    QPushButton *pushButton_C12;
    QHBoxLayout *horizontalLayout_rowD;
    QPushButton *pushButton_D1;
    QPushButton *pushButton_D2;
    QPushButton *pushButton_D3;
    QPushButton *pushButton_D4;
    QPushButton *pushButton_D5;
    QPushButton *pushButton_D6;
    QPushButton *pushButton_D7;
    QPushButton *pushButton_D8;
    QPushButton *pushButton_D9;
    QPushButton *pushButton_D10;
    QPushButton *pushButton_D11;
    QPushButton *pushButton_D12;
    QHBoxLayout *horizontalLayout_rowE;
    QPushButton *pushButton_E1;
    QPushButton *pushButton_E2;
    QPushButton *pushButton_E3;
    QPushButton *pushButton_E4;
    QPushButton *pushButton_E5;
    QPushButton *pushButton_E6;
    QPushButton *pushButton_E7;
    QPushButton *pushButton_E8;
    QPushButton *pushButton_E9;
    QPushButton *pushButton_E10;
    QPushButton *pushButton_E11;
    QPushButton *pushButton_E12;
    QHBoxLayout *horizontalLayout_rowF;
    QPushButton *pushButton_F1;
    QPushButton *pushButton_F2;
    QPushButton *pushButton_F3;
    QPushButton *pushButton_F4;
    QPushButton *pushButton_F5;
    QPushButton *pushButton_F6;
    QPushButton *pushButton_F7;
    QPushButton *pushButton_F8;
    QPushButton *pushButton_F9;
    QPushButton *pushButton_F10;
    QPushButton *pushButton_F11;
    QPushButton *pushButton_F12;
    QHBoxLayout *horizontalLayout_rowG;
    QPushButton *pushButton_G1;
    QPushButton *pushButton_G2;
    QPushButton *pushButton_G3;
    QPushButton *pushButton_G4;
    QPushButton *pushButton_G5;
    QPushButton *pushButton_G6;
    QPushButton *pushButton_G7;
    QPushButton *pushButton_G8;
    QPushButton *pushButton_G9;
    QPushButton *pushButton_G10;
    QPushButton *pushButton_G11;
    QPushButton *pushButton_G12;
    QHBoxLayout *horizontalLayout_rowH;
    QPushButton *pushButton_H1;
    QPushButton *pushButton_H2;
    QPushButton *pushButton_H3;
    QPushButton *pushButton_H4;
    QPushButton *pushButton_H5;
    QPushButton *pushButton_H6;
    QPushButton *pushButton_H7;
    QPushButton *pushButton_H8;
    QPushButton *pushButton_H9;
    QPushButton *pushButton_H10;
    QPushButton *pushButton_H11;
    QPushButton *pushButton_H12;
    QSpacerItem *verticalSpacer_2;
    QHBoxLayout *horizontalLayout;
    QSpacerItem *horizontalSpacer;
    QPushButton *pushButton;

    void setupUi(QDialog *SeatAvailability)
    {
        if (SeatAvailability->objectName().isEmpty())
            SeatAvailability->setObjectName(QString::fromUtf8("SeatAvailability"));
        SeatAvailability->resize(1126, 640);
        verticalLayout = new QVBoxLayout(SeatAvailability);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        label_screen = new QLabel(SeatAvailability);
        label_screen->setObjectName(QString::fromUtf8("label_screen"));
        QSizePolicy sizePolicy(QSizePolicy::Preferred, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(label_screen->sizePolicy().hasHeightForWidth());
        label_screen->setSizePolicy(sizePolicy);
        label_screen->setMinimumSize(QSize(800, 40));
        label_screen->setAutoFillBackground(false);
        label_screen->setLocale(QLocale(QLocale::English, QLocale::UnitedStates));
        label_screen->setLineWidth(5);
        label_screen->setAlignment(Qt::AlignCenter);

        verticalLayout->addWidget(label_screen);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout->addItem(verticalSpacer);

        verticalLayout_allRows = new QVBoxLayout();
        verticalLayout_allRows->setSpacing(20);
        verticalLayout_allRows->setObjectName(QString::fromUtf8("verticalLayout_allRows"));
        verticalLayout_allRows->setContentsMargins(40, -1, 40, 0);
        horizontalLayout_rowA = new QHBoxLayout();
        horizontalLayout_rowA->setObjectName(QString::fromUtf8("horizontalLayout_rowA"));
        pushButton_A1 = new QPushButton(SeatAvailability);
        pushButton_A1->setObjectName(QString::fromUtf8("pushButton_A1"));
        pushButton_A1->setCheckable(true);

        horizontalLayout_rowA->addWidget(pushButton_A1);

        pushButton_A2 = new QPushButton(SeatAvailability);
        pushButton_A2->setObjectName(QString::fromUtf8("pushButton_A2"));
        pushButton_A2->setCheckable(true);

        horizontalLayout_rowA->addWidget(pushButton_A2);

        pushButton_A3 = new QPushButton(SeatAvailability);
        pushButton_A3->setObjectName(QString::fromUtf8("pushButton_A3"));
        pushButton_A3->setCheckable(true);

        horizontalLayout_rowA->addWidget(pushButton_A3);

        pushButton_A4 = new QPushButton(SeatAvailability);
        pushButton_A4->setObjectName(QString::fromUtf8("pushButton_A4"));
        pushButton_A4->setCheckable(true);

        horizontalLayout_rowA->addWidget(pushButton_A4);

        pushButton_A5 = new QPushButton(SeatAvailability);
        pushButton_A5->setObjectName(QString::fromUtf8("pushButton_A5"));
        pushButton_A5->setCheckable(true);

        horizontalLayout_rowA->addWidget(pushButton_A5);

        pushButton_A6 = new QPushButton(SeatAvailability);
        pushButton_A6->setObjectName(QString::fromUtf8("pushButton_A6"));
        pushButton_A6->setCheckable(true);

        horizontalLayout_rowA->addWidget(pushButton_A6);

        pushButton_A7 = new QPushButton(SeatAvailability);
        pushButton_A7->setObjectName(QString::fromUtf8("pushButton_A7"));
        pushButton_A7->setCheckable(true);

        horizontalLayout_rowA->addWidget(pushButton_A7);

        pushButton_A8 = new QPushButton(SeatAvailability);
        pushButton_A8->setObjectName(QString::fromUtf8("pushButton_A8"));
        pushButton_A8->setCheckable(true);

        horizontalLayout_rowA->addWidget(pushButton_A8);

        pushButton_A9 = new QPushButton(SeatAvailability);
        pushButton_A9->setObjectName(QString::fromUtf8("pushButton_A9"));
        pushButton_A9->setCheckable(true);

        horizontalLayout_rowA->addWidget(pushButton_A9);

        pushButton_A10 = new QPushButton(SeatAvailability);
        pushButton_A10->setObjectName(QString::fromUtf8("pushButton_A10"));
        pushButton_A10->setCheckable(true);

        horizontalLayout_rowA->addWidget(pushButton_A10);

        pushButton_A11 = new QPushButton(SeatAvailability);
        pushButton_A11->setObjectName(QString::fromUtf8("pushButton_A11"));
        pushButton_A11->setCheckable(true);

        horizontalLayout_rowA->addWidget(pushButton_A11);

        pushButton_A12 = new QPushButton(SeatAvailability);
        pushButton_A12->setObjectName(QString::fromUtf8("pushButton_A12"));
        pushButton_A12->setCheckable(true);

        horizontalLayout_rowA->addWidget(pushButton_A12);


        verticalLayout_allRows->addLayout(horizontalLayout_rowA);

        horizontalLayout_rowB = new QHBoxLayout();
        horizontalLayout_rowB->setObjectName(QString::fromUtf8("horizontalLayout_rowB"));
        pushButton_B1 = new QPushButton(SeatAvailability);
        pushButton_B1->setObjectName(QString::fromUtf8("pushButton_B1"));
        pushButton_B1->setCheckable(true);

        horizontalLayout_rowB->addWidget(pushButton_B1);

        pushButton_B2 = new QPushButton(SeatAvailability);
        pushButton_B2->setObjectName(QString::fromUtf8("pushButton_B2"));
        pushButton_B2->setCheckable(true);

        horizontalLayout_rowB->addWidget(pushButton_B2);

        pushButton_B3 = new QPushButton(SeatAvailability);
        pushButton_B3->setObjectName(QString::fromUtf8("pushButton_B3"));
        pushButton_B3->setCheckable(true);

        horizontalLayout_rowB->addWidget(pushButton_B3);

        pushButton_B4 = new QPushButton(SeatAvailability);
        pushButton_B4->setObjectName(QString::fromUtf8("pushButton_B4"));
        pushButton_B4->setCheckable(true);

        horizontalLayout_rowB->addWidget(pushButton_B4);

        pushButton_B5 = new QPushButton(SeatAvailability);
        pushButton_B5->setObjectName(QString::fromUtf8("pushButton_B5"));
        pushButton_B5->setCheckable(true);

        horizontalLayout_rowB->addWidget(pushButton_B5);

        pushButton_B6 = new QPushButton(SeatAvailability);
        pushButton_B6->setObjectName(QString::fromUtf8("pushButton_B6"));
        pushButton_B6->setCheckable(true);

        horizontalLayout_rowB->addWidget(pushButton_B6);

        pushButton_B7 = new QPushButton(SeatAvailability);
        pushButton_B7->setObjectName(QString::fromUtf8("pushButton_B7"));
        pushButton_B7->setCheckable(true);

        horizontalLayout_rowB->addWidget(pushButton_B7);

        pushButton_B8 = new QPushButton(SeatAvailability);
        pushButton_B8->setObjectName(QString::fromUtf8("pushButton_B8"));
        pushButton_B8->setCheckable(true);

        horizontalLayout_rowB->addWidget(pushButton_B8);

        pushButton_B9 = new QPushButton(SeatAvailability);
        pushButton_B9->setObjectName(QString::fromUtf8("pushButton_B9"));
        pushButton_B9->setCheckable(true);

        horizontalLayout_rowB->addWidget(pushButton_B9);

        pushButton_B10 = new QPushButton(SeatAvailability);
        pushButton_B10->setObjectName(QString::fromUtf8("pushButton_B10"));
        pushButton_B10->setCheckable(true);

        horizontalLayout_rowB->addWidget(pushButton_B10);

        pushButton_B11 = new QPushButton(SeatAvailability);
        pushButton_B11->setObjectName(QString::fromUtf8("pushButton_B11"));
        pushButton_B11->setCheckable(true);

        horizontalLayout_rowB->addWidget(pushButton_B11);

        pushButton_B12 = new QPushButton(SeatAvailability);
        pushButton_B12->setObjectName(QString::fromUtf8("pushButton_B12"));
        pushButton_B12->setCheckable(true);

        horizontalLayout_rowB->addWidget(pushButton_B12);


        verticalLayout_allRows->addLayout(horizontalLayout_rowB);

        horizontalLayout_rowC = new QHBoxLayout();
        horizontalLayout_rowC->setObjectName(QString::fromUtf8("horizontalLayout_rowC"));
        pushButton_C1 = new QPushButton(SeatAvailability);
        pushButton_C1->setObjectName(QString::fromUtf8("pushButton_C1"));
        pushButton_C1->setCheckable(true);

        horizontalLayout_rowC->addWidget(pushButton_C1);

        pushButton_C2 = new QPushButton(SeatAvailability);
        pushButton_C2->setObjectName(QString::fromUtf8("pushButton_C2"));
        pushButton_C2->setCheckable(true);

        horizontalLayout_rowC->addWidget(pushButton_C2);

        pushButton_C3 = new QPushButton(SeatAvailability);
        pushButton_C3->setObjectName(QString::fromUtf8("pushButton_C3"));
        pushButton_C3->setCheckable(true);

        horizontalLayout_rowC->addWidget(pushButton_C3);

        pushButton_C4 = new QPushButton(SeatAvailability);
        pushButton_C4->setObjectName(QString::fromUtf8("pushButton_C4"));
        pushButton_C4->setCheckable(true);

        horizontalLayout_rowC->addWidget(pushButton_C4);

        pushButton_C5 = new QPushButton(SeatAvailability);
        pushButton_C5->setObjectName(QString::fromUtf8("pushButton_C5"));
        pushButton_C5->setCheckable(true);

        horizontalLayout_rowC->addWidget(pushButton_C5);

        pushButton_C6 = new QPushButton(SeatAvailability);
        pushButton_C6->setObjectName(QString::fromUtf8("pushButton_C6"));
        pushButton_C6->setCheckable(true);

        horizontalLayout_rowC->addWidget(pushButton_C6);

        pushButton_C7 = new QPushButton(SeatAvailability);
        pushButton_C7->setObjectName(QString::fromUtf8("pushButton_C7"));
        pushButton_C7->setCheckable(true);

        horizontalLayout_rowC->addWidget(pushButton_C7);

        pushButton_C8 = new QPushButton(SeatAvailability);
        pushButton_C8->setObjectName(QString::fromUtf8("pushButton_C8"));
        pushButton_C8->setCheckable(true);

        horizontalLayout_rowC->addWidget(pushButton_C8);

        pushButton_C9 = new QPushButton(SeatAvailability);
        pushButton_C9->setObjectName(QString::fromUtf8("pushButton_C9"));
        pushButton_C9->setCheckable(true);

        horizontalLayout_rowC->addWidget(pushButton_C9);

        pushButton_C10 = new QPushButton(SeatAvailability);
        pushButton_C10->setObjectName(QString::fromUtf8("pushButton_C10"));
        pushButton_C10->setCheckable(true);

        horizontalLayout_rowC->addWidget(pushButton_C10);

        pushButton_C11 = new QPushButton(SeatAvailability);
        pushButton_C11->setObjectName(QString::fromUtf8("pushButton_C11"));
        pushButton_C11->setCheckable(true);

        horizontalLayout_rowC->addWidget(pushButton_C11);

        pushButton_C12 = new QPushButton(SeatAvailability);
        pushButton_C12->setObjectName(QString::fromUtf8("pushButton_C12"));
        pushButton_C12->setCheckable(true);

        horizontalLayout_rowC->addWidget(pushButton_C12);


        verticalLayout_allRows->addLayout(horizontalLayout_rowC);

        horizontalLayout_rowD = new QHBoxLayout();
        horizontalLayout_rowD->setObjectName(QString::fromUtf8("horizontalLayout_rowD"));
        pushButton_D1 = new QPushButton(SeatAvailability);
        pushButton_D1->setObjectName(QString::fromUtf8("pushButton_D1"));
        pushButton_D1->setCheckable(true);

        horizontalLayout_rowD->addWidget(pushButton_D1);

        pushButton_D2 = new QPushButton(SeatAvailability);
        pushButton_D2->setObjectName(QString::fromUtf8("pushButton_D2"));
        pushButton_D2->setCheckable(true);

        horizontalLayout_rowD->addWidget(pushButton_D2);

        pushButton_D3 = new QPushButton(SeatAvailability);
        pushButton_D3->setObjectName(QString::fromUtf8("pushButton_D3"));
        pushButton_D3->setCheckable(true);

        horizontalLayout_rowD->addWidget(pushButton_D3);

        pushButton_D4 = new QPushButton(SeatAvailability);
        pushButton_D4->setObjectName(QString::fromUtf8("pushButton_D4"));
        pushButton_D4->setCheckable(true);

        horizontalLayout_rowD->addWidget(pushButton_D4);

        pushButton_D5 = new QPushButton(SeatAvailability);
        pushButton_D5->setObjectName(QString::fromUtf8("pushButton_D5"));
        pushButton_D5->setCheckable(true);

        horizontalLayout_rowD->addWidget(pushButton_D5);

        pushButton_D6 = new QPushButton(SeatAvailability);
        pushButton_D6->setObjectName(QString::fromUtf8("pushButton_D6"));
        pushButton_D6->setCheckable(true);

        horizontalLayout_rowD->addWidget(pushButton_D6);

        pushButton_D7 = new QPushButton(SeatAvailability);
        pushButton_D7->setObjectName(QString::fromUtf8("pushButton_D7"));
        pushButton_D7->setCheckable(true);

        horizontalLayout_rowD->addWidget(pushButton_D7);

        pushButton_D8 = new QPushButton(SeatAvailability);
        pushButton_D8->setObjectName(QString::fromUtf8("pushButton_D8"));
        pushButton_D8->setCheckable(true);

        horizontalLayout_rowD->addWidget(pushButton_D8);

        pushButton_D9 = new QPushButton(SeatAvailability);
        pushButton_D9->setObjectName(QString::fromUtf8("pushButton_D9"));
        pushButton_D9->setCheckable(true);

        horizontalLayout_rowD->addWidget(pushButton_D9);

        pushButton_D10 = new QPushButton(SeatAvailability);
        pushButton_D10->setObjectName(QString::fromUtf8("pushButton_D10"));
        pushButton_D10->setCheckable(true);

        horizontalLayout_rowD->addWidget(pushButton_D10);

        pushButton_D11 = new QPushButton(SeatAvailability);
        pushButton_D11->setObjectName(QString::fromUtf8("pushButton_D11"));
        pushButton_D11->setCheckable(true);

        horizontalLayout_rowD->addWidget(pushButton_D11);

        pushButton_D12 = new QPushButton(SeatAvailability);
        pushButton_D12->setObjectName(QString::fromUtf8("pushButton_D12"));
        pushButton_D12->setCheckable(true);

        horizontalLayout_rowD->addWidget(pushButton_D12);


        verticalLayout_allRows->addLayout(horizontalLayout_rowD);

        horizontalLayout_rowE = new QHBoxLayout();
        horizontalLayout_rowE->setObjectName(QString::fromUtf8("horizontalLayout_rowE"));
        pushButton_E1 = new QPushButton(SeatAvailability);
        pushButton_E1->setObjectName(QString::fromUtf8("pushButton_E1"));
        pushButton_E1->setCheckable(true);

        horizontalLayout_rowE->addWidget(pushButton_E1);

        pushButton_E2 = new QPushButton(SeatAvailability);
        pushButton_E2->setObjectName(QString::fromUtf8("pushButton_E2"));
        pushButton_E2->setCheckable(true);

        horizontalLayout_rowE->addWidget(pushButton_E2);

        pushButton_E3 = new QPushButton(SeatAvailability);
        pushButton_E3->setObjectName(QString::fromUtf8("pushButton_E3"));
        pushButton_E3->setCheckable(true);

        horizontalLayout_rowE->addWidget(pushButton_E3);

        pushButton_E4 = new QPushButton(SeatAvailability);
        pushButton_E4->setObjectName(QString::fromUtf8("pushButton_E4"));
        pushButton_E4->setCheckable(true);

        horizontalLayout_rowE->addWidget(pushButton_E4);

        pushButton_E5 = new QPushButton(SeatAvailability);
        pushButton_E5->setObjectName(QString::fromUtf8("pushButton_E5"));
        pushButton_E5->setCheckable(true);

        horizontalLayout_rowE->addWidget(pushButton_E5);

        pushButton_E6 = new QPushButton(SeatAvailability);
        pushButton_E6->setObjectName(QString::fromUtf8("pushButton_E6"));
        pushButton_E6->setCheckable(true);

        horizontalLayout_rowE->addWidget(pushButton_E6);

        pushButton_E7 = new QPushButton(SeatAvailability);
        pushButton_E7->setObjectName(QString::fromUtf8("pushButton_E7"));
        pushButton_E7->setCheckable(true);

        horizontalLayout_rowE->addWidget(pushButton_E7);

        pushButton_E8 = new QPushButton(SeatAvailability);
        pushButton_E8->setObjectName(QString::fromUtf8("pushButton_E8"));
        pushButton_E8->setCheckable(true);

        horizontalLayout_rowE->addWidget(pushButton_E8);

        pushButton_E9 = new QPushButton(SeatAvailability);
        pushButton_E9->setObjectName(QString::fromUtf8("pushButton_E9"));
        pushButton_E9->setCheckable(true);

        horizontalLayout_rowE->addWidget(pushButton_E9);

        pushButton_E10 = new QPushButton(SeatAvailability);
        pushButton_E10->setObjectName(QString::fromUtf8("pushButton_E10"));
        pushButton_E10->setCheckable(true);

        horizontalLayout_rowE->addWidget(pushButton_E10);

        pushButton_E11 = new QPushButton(SeatAvailability);
        pushButton_E11->setObjectName(QString::fromUtf8("pushButton_E11"));
        pushButton_E11->setCheckable(true);

        horizontalLayout_rowE->addWidget(pushButton_E11);

        pushButton_E12 = new QPushButton(SeatAvailability);
        pushButton_E12->setObjectName(QString::fromUtf8("pushButton_E12"));
        pushButton_E12->setCheckable(true);

        horizontalLayout_rowE->addWidget(pushButton_E12);


        verticalLayout_allRows->addLayout(horizontalLayout_rowE);

        horizontalLayout_rowF = new QHBoxLayout();
        horizontalLayout_rowF->setObjectName(QString::fromUtf8("horizontalLayout_rowF"));
        pushButton_F1 = new QPushButton(SeatAvailability);
        pushButton_F1->setObjectName(QString::fromUtf8("pushButton_F1"));
        pushButton_F1->setCheckable(true);

        horizontalLayout_rowF->addWidget(pushButton_F1);

        pushButton_F2 = new QPushButton(SeatAvailability);
        pushButton_F2->setObjectName(QString::fromUtf8("pushButton_F2"));
        pushButton_F2->setCheckable(true);

        horizontalLayout_rowF->addWidget(pushButton_F2);

        pushButton_F3 = new QPushButton(SeatAvailability);
        pushButton_F3->setObjectName(QString::fromUtf8("pushButton_F3"));
        pushButton_F3->setCheckable(true);

        horizontalLayout_rowF->addWidget(pushButton_F3);

        pushButton_F4 = new QPushButton(SeatAvailability);
        pushButton_F4->setObjectName(QString::fromUtf8("pushButton_F4"));
        pushButton_F4->setCheckable(true);

        horizontalLayout_rowF->addWidget(pushButton_F4);

        pushButton_F5 = new QPushButton(SeatAvailability);
        pushButton_F5->setObjectName(QString::fromUtf8("pushButton_F5"));
        pushButton_F5->setCheckable(true);

        horizontalLayout_rowF->addWidget(pushButton_F5);

        pushButton_F6 = new QPushButton(SeatAvailability);
        pushButton_F6->setObjectName(QString::fromUtf8("pushButton_F6"));
        pushButton_F6->setCheckable(true);

        horizontalLayout_rowF->addWidget(pushButton_F6);

        pushButton_F7 = new QPushButton(SeatAvailability);
        pushButton_F7->setObjectName(QString::fromUtf8("pushButton_F7"));
        pushButton_F7->setCheckable(true);

        horizontalLayout_rowF->addWidget(pushButton_F7);

        pushButton_F8 = new QPushButton(SeatAvailability);
        pushButton_F8->setObjectName(QString::fromUtf8("pushButton_F8"));
        pushButton_F8->setCheckable(true);

        horizontalLayout_rowF->addWidget(pushButton_F8);

        pushButton_F9 = new QPushButton(SeatAvailability);
        pushButton_F9->setObjectName(QString::fromUtf8("pushButton_F9"));
        pushButton_F9->setCheckable(true);

        horizontalLayout_rowF->addWidget(pushButton_F9);

        pushButton_F10 = new QPushButton(SeatAvailability);
        pushButton_F10->setObjectName(QString::fromUtf8("pushButton_F10"));
        pushButton_F10->setCheckable(true);

        horizontalLayout_rowF->addWidget(pushButton_F10);

        pushButton_F11 = new QPushButton(SeatAvailability);
        pushButton_F11->setObjectName(QString::fromUtf8("pushButton_F11"));
        pushButton_F11->setCheckable(true);

        horizontalLayout_rowF->addWidget(pushButton_F11);

        pushButton_F12 = new QPushButton(SeatAvailability);
        pushButton_F12->setObjectName(QString::fromUtf8("pushButton_F12"));
        pushButton_F12->setCheckable(true);

        horizontalLayout_rowF->addWidget(pushButton_F12);


        verticalLayout_allRows->addLayout(horizontalLayout_rowF);

        horizontalLayout_rowG = new QHBoxLayout();
        horizontalLayout_rowG->setObjectName(QString::fromUtf8("horizontalLayout_rowG"));
        pushButton_G1 = new QPushButton(SeatAvailability);
        pushButton_G1->setObjectName(QString::fromUtf8("pushButton_G1"));
        pushButton_G1->setCheckable(true);

        horizontalLayout_rowG->addWidget(pushButton_G1);

        pushButton_G2 = new QPushButton(SeatAvailability);
        pushButton_G2->setObjectName(QString::fromUtf8("pushButton_G2"));
        pushButton_G2->setCheckable(true);

        horizontalLayout_rowG->addWidget(pushButton_G2);

        pushButton_G3 = new QPushButton(SeatAvailability);
        pushButton_G3->setObjectName(QString::fromUtf8("pushButton_G3"));
        pushButton_G3->setCheckable(true);

        horizontalLayout_rowG->addWidget(pushButton_G3);

        pushButton_G4 = new QPushButton(SeatAvailability);
        pushButton_G4->setObjectName(QString::fromUtf8("pushButton_G4"));
        pushButton_G4->setCheckable(true);

        horizontalLayout_rowG->addWidget(pushButton_G4);

        pushButton_G5 = new QPushButton(SeatAvailability);
        pushButton_G5->setObjectName(QString::fromUtf8("pushButton_G5"));
        pushButton_G5->setCheckable(true);

        horizontalLayout_rowG->addWidget(pushButton_G5);

        pushButton_G6 = new QPushButton(SeatAvailability);
        pushButton_G6->setObjectName(QString::fromUtf8("pushButton_G6"));
        pushButton_G6->setCheckable(true);

        horizontalLayout_rowG->addWidget(pushButton_G6);

        pushButton_G7 = new QPushButton(SeatAvailability);
        pushButton_G7->setObjectName(QString::fromUtf8("pushButton_G7"));
        pushButton_G7->setCheckable(true);

        horizontalLayout_rowG->addWidget(pushButton_G7);

        pushButton_G8 = new QPushButton(SeatAvailability);
        pushButton_G8->setObjectName(QString::fromUtf8("pushButton_G8"));
        pushButton_G8->setCheckable(true);

        horizontalLayout_rowG->addWidget(pushButton_G8);

        pushButton_G9 = new QPushButton(SeatAvailability);
        pushButton_G9->setObjectName(QString::fromUtf8("pushButton_G9"));
        pushButton_G9->setCheckable(true);

        horizontalLayout_rowG->addWidget(pushButton_G9);

        pushButton_G10 = new QPushButton(SeatAvailability);
        pushButton_G10->setObjectName(QString::fromUtf8("pushButton_G10"));
        pushButton_G10->setCheckable(true);

        horizontalLayout_rowG->addWidget(pushButton_G10);

        pushButton_G11 = new QPushButton(SeatAvailability);
        pushButton_G11->setObjectName(QString::fromUtf8("pushButton_G11"));
        pushButton_G11->setCheckable(true);

        horizontalLayout_rowG->addWidget(pushButton_G11);

        pushButton_G12 = new QPushButton(SeatAvailability);
        pushButton_G12->setObjectName(QString::fromUtf8("pushButton_G12"));
        pushButton_G12->setCheckable(true);

        horizontalLayout_rowG->addWidget(pushButton_G12);


        verticalLayout_allRows->addLayout(horizontalLayout_rowG);

        horizontalLayout_rowH = new QHBoxLayout();
        horizontalLayout_rowH->setObjectName(QString::fromUtf8("horizontalLayout_rowH"));
        pushButton_H1 = new QPushButton(SeatAvailability);
        pushButton_H1->setObjectName(QString::fromUtf8("pushButton_H1"));
        pushButton_H1->setCheckable(true);

        horizontalLayout_rowH->addWidget(pushButton_H1);

        pushButton_H2 = new QPushButton(SeatAvailability);
        pushButton_H2->setObjectName(QString::fromUtf8("pushButton_H2"));
        pushButton_H2->setCheckable(true);

        horizontalLayout_rowH->addWidget(pushButton_H2);

        pushButton_H3 = new QPushButton(SeatAvailability);
        pushButton_H3->setObjectName(QString::fromUtf8("pushButton_H3"));
        pushButton_H3->setCheckable(true);

        horizontalLayout_rowH->addWidget(pushButton_H3);

        pushButton_H4 = new QPushButton(SeatAvailability);
        pushButton_H4->setObjectName(QString::fromUtf8("pushButton_H4"));
        pushButton_H4->setCheckable(true);

        horizontalLayout_rowH->addWidget(pushButton_H4);

        pushButton_H5 = new QPushButton(SeatAvailability);
        pushButton_H5->setObjectName(QString::fromUtf8("pushButton_H5"));
        pushButton_H5->setCheckable(true);

        horizontalLayout_rowH->addWidget(pushButton_H5);

        pushButton_H6 = new QPushButton(SeatAvailability);
        pushButton_H6->setObjectName(QString::fromUtf8("pushButton_H6"));
        pushButton_H6->setCheckable(true);

        horizontalLayout_rowH->addWidget(pushButton_H6);

        pushButton_H7 = new QPushButton(SeatAvailability);
        pushButton_H7->setObjectName(QString::fromUtf8("pushButton_H7"));
        pushButton_H7->setEnabled(true);
        pushButton_H7->setCheckable(true);
        pushButton_H7->setChecked(false);

        horizontalLayout_rowH->addWidget(pushButton_H7);

        pushButton_H8 = new QPushButton(SeatAvailability);
        pushButton_H8->setObjectName(QString::fromUtf8("pushButton_H8"));
        pushButton_H8->setCheckable(true);

        horizontalLayout_rowH->addWidget(pushButton_H8);

        pushButton_H9 = new QPushButton(SeatAvailability);
        pushButton_H9->setObjectName(QString::fromUtf8("pushButton_H9"));
        pushButton_H9->setCheckable(true);

        horizontalLayout_rowH->addWidget(pushButton_H9);

        pushButton_H10 = new QPushButton(SeatAvailability);
        pushButton_H10->setObjectName(QString::fromUtf8("pushButton_H10"));
        pushButton_H10->setCheckable(true);

        horizontalLayout_rowH->addWidget(pushButton_H10);

        pushButton_H11 = new QPushButton(SeatAvailability);
        pushButton_H11->setObjectName(QString::fromUtf8("pushButton_H11"));
        pushButton_H11->setCheckable(true);

        horizontalLayout_rowH->addWidget(pushButton_H11);

        pushButton_H12 = new QPushButton(SeatAvailability);
        pushButton_H12->setObjectName(QString::fromUtf8("pushButton_H12"));
        pushButton_H12->setCheckable(true);

        horizontalLayout_rowH->addWidget(pushButton_H12);


        verticalLayout_allRows->addLayout(horizontalLayout_rowH);


        verticalLayout->addLayout(verticalLayout_allRows);

        verticalSpacer_2 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout->addItem(verticalSpacer_2);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer);

        pushButton = new QPushButton(SeatAvailability);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        sizePolicy.setHeightForWidth(pushButton->sizePolicy().hasHeightForWidth());
        pushButton->setSizePolicy(sizePolicy);

        horizontalLayout->addWidget(pushButton);


        verticalLayout->addLayout(horizontalLayout);


        retranslateUi(SeatAvailability);

        QMetaObject::connectSlotsByName(SeatAvailability);
    } // setupUi

    void retranslateUi(QDialog *SeatAvailability)
    {
        SeatAvailability->setWindowTitle(QCoreApplication::translate("SeatAvailability", "Dialog", nullptr));
        label_screen->setText(QCoreApplication::translate("SeatAvailability", "<html><head/><body><p><span style=\" font-size:14pt; font-weight:600; border: 1px solid black;\">SCREEN</span></p></body></html>", nullptr));
        pushButton_A1->setText(QCoreApplication::translate("SeatAvailability", "A1", nullptr));
        pushButton_A2->setText(QCoreApplication::translate("SeatAvailability", "A2", nullptr));
        pushButton_A3->setText(QCoreApplication::translate("SeatAvailability", "A3", nullptr));
        pushButton_A4->setText(QCoreApplication::translate("SeatAvailability", "A4", nullptr));
        pushButton_A5->setText(QCoreApplication::translate("SeatAvailability", "A5", nullptr));
        pushButton_A6->setText(QCoreApplication::translate("SeatAvailability", "A6", nullptr));
        pushButton_A7->setText(QCoreApplication::translate("SeatAvailability", "A7", nullptr));
        pushButton_A8->setText(QCoreApplication::translate("SeatAvailability", "A8", nullptr));
        pushButton_A9->setText(QCoreApplication::translate("SeatAvailability", "A9", nullptr));
        pushButton_A10->setText(QCoreApplication::translate("SeatAvailability", "A10", nullptr));
        pushButton_A11->setText(QCoreApplication::translate("SeatAvailability", "A11", nullptr));
        pushButton_A12->setText(QCoreApplication::translate("SeatAvailability", "A12", nullptr));
        pushButton_B1->setText(QCoreApplication::translate("SeatAvailability", "B1", nullptr));
        pushButton_B2->setText(QCoreApplication::translate("SeatAvailability", "B2", nullptr));
        pushButton_B3->setText(QCoreApplication::translate("SeatAvailability", "B3", nullptr));
        pushButton_B4->setText(QCoreApplication::translate("SeatAvailability", "B4", nullptr));
        pushButton_B5->setText(QCoreApplication::translate("SeatAvailability", "B5", nullptr));
        pushButton_B6->setText(QCoreApplication::translate("SeatAvailability", "B6", nullptr));
        pushButton_B7->setText(QCoreApplication::translate("SeatAvailability", "B7", nullptr));
        pushButton_B8->setText(QCoreApplication::translate("SeatAvailability", "B8", nullptr));
        pushButton_B9->setText(QCoreApplication::translate("SeatAvailability", "B9", nullptr));
        pushButton_B10->setText(QCoreApplication::translate("SeatAvailability", "B10", nullptr));
        pushButton_B11->setText(QCoreApplication::translate("SeatAvailability", "B11", nullptr));
        pushButton_B12->setText(QCoreApplication::translate("SeatAvailability", "B12", nullptr));
        pushButton_C1->setText(QCoreApplication::translate("SeatAvailability", "C1", nullptr));
        pushButton_C2->setText(QCoreApplication::translate("SeatAvailability", "C2", nullptr));
        pushButton_C3->setText(QCoreApplication::translate("SeatAvailability", "C3", nullptr));
        pushButton_C4->setText(QCoreApplication::translate("SeatAvailability", "C4", nullptr));
        pushButton_C5->setText(QCoreApplication::translate("SeatAvailability", "C5", nullptr));
        pushButton_C6->setText(QCoreApplication::translate("SeatAvailability", "C6", nullptr));
        pushButton_C7->setText(QCoreApplication::translate("SeatAvailability", "C7", nullptr));
        pushButton_C8->setText(QCoreApplication::translate("SeatAvailability", "C8", nullptr));
        pushButton_C9->setText(QCoreApplication::translate("SeatAvailability", "C9", nullptr));
        pushButton_C10->setText(QCoreApplication::translate("SeatAvailability", "C10", nullptr));
        pushButton_C11->setText(QCoreApplication::translate("SeatAvailability", "C11", nullptr));
        pushButton_C12->setText(QCoreApplication::translate("SeatAvailability", "C12", nullptr));
        pushButton_D1->setText(QCoreApplication::translate("SeatAvailability", "D1", nullptr));
        pushButton_D2->setText(QCoreApplication::translate("SeatAvailability", "D2", nullptr));
        pushButton_D3->setText(QCoreApplication::translate("SeatAvailability", "D3", nullptr));
        pushButton_D4->setText(QCoreApplication::translate("SeatAvailability", "D4", nullptr));
        pushButton_D5->setText(QCoreApplication::translate("SeatAvailability", "D5", nullptr));
        pushButton_D6->setText(QCoreApplication::translate("SeatAvailability", "D6", nullptr));
        pushButton_D7->setText(QCoreApplication::translate("SeatAvailability", "D7", nullptr));
        pushButton_D8->setText(QCoreApplication::translate("SeatAvailability", "D8", nullptr));
        pushButton_D9->setText(QCoreApplication::translate("SeatAvailability", "D9", nullptr));
        pushButton_D10->setText(QCoreApplication::translate("SeatAvailability", "D10", nullptr));
        pushButton_D11->setText(QCoreApplication::translate("SeatAvailability", "D11", nullptr));
        pushButton_D12->setText(QCoreApplication::translate("SeatAvailability", "D12", nullptr));
        pushButton_E1->setText(QCoreApplication::translate("SeatAvailability", "E1", nullptr));
        pushButton_E2->setText(QCoreApplication::translate("SeatAvailability", "E2", nullptr));
        pushButton_E3->setText(QCoreApplication::translate("SeatAvailability", "E3", nullptr));
        pushButton_E4->setText(QCoreApplication::translate("SeatAvailability", "E4", nullptr));
        pushButton_E5->setText(QCoreApplication::translate("SeatAvailability", "E5", nullptr));
        pushButton_E6->setText(QCoreApplication::translate("SeatAvailability", "E6", nullptr));
        pushButton_E7->setText(QCoreApplication::translate("SeatAvailability", "E7", nullptr));
        pushButton_E8->setText(QCoreApplication::translate("SeatAvailability", "E8", nullptr));
        pushButton_E9->setText(QCoreApplication::translate("SeatAvailability", "E9", nullptr));
        pushButton_E10->setText(QCoreApplication::translate("SeatAvailability", "E10", nullptr));
        pushButton_E11->setText(QCoreApplication::translate("SeatAvailability", "E11", nullptr));
        pushButton_E12->setText(QCoreApplication::translate("SeatAvailability", "E12", nullptr));
        pushButton_F1->setText(QCoreApplication::translate("SeatAvailability", "F1", nullptr));
        pushButton_F2->setText(QCoreApplication::translate("SeatAvailability", "F2", nullptr));
        pushButton_F3->setText(QCoreApplication::translate("SeatAvailability", "F3", nullptr));
        pushButton_F4->setText(QCoreApplication::translate("SeatAvailability", "F4", nullptr));
        pushButton_F5->setText(QCoreApplication::translate("SeatAvailability", "F5", nullptr));
        pushButton_F6->setText(QCoreApplication::translate("SeatAvailability", "F6", nullptr));
        pushButton_F7->setText(QCoreApplication::translate("SeatAvailability", "F7", nullptr));
        pushButton_F8->setText(QCoreApplication::translate("SeatAvailability", "F8", nullptr));
        pushButton_F9->setText(QCoreApplication::translate("SeatAvailability", "F9", nullptr));
        pushButton_F10->setText(QCoreApplication::translate("SeatAvailability", "F10", nullptr));
        pushButton_F11->setText(QCoreApplication::translate("SeatAvailability", "F11", nullptr));
        pushButton_F12->setText(QCoreApplication::translate("SeatAvailability", "F12", nullptr));
        pushButton_G1->setText(QCoreApplication::translate("SeatAvailability", "G1", nullptr));
        pushButton_G2->setText(QCoreApplication::translate("SeatAvailability", "G2", nullptr));
        pushButton_G3->setText(QCoreApplication::translate("SeatAvailability", "G3", nullptr));
        pushButton_G4->setText(QCoreApplication::translate("SeatAvailability", "G4", nullptr));
        pushButton_G5->setText(QCoreApplication::translate("SeatAvailability", "G5", nullptr));
        pushButton_G6->setText(QCoreApplication::translate("SeatAvailability", "G6", nullptr));
        pushButton_G7->setText(QCoreApplication::translate("SeatAvailability", "G7", nullptr));
        pushButton_G8->setText(QCoreApplication::translate("SeatAvailability", "G8", nullptr));
        pushButton_G9->setText(QCoreApplication::translate("SeatAvailability", "G9", nullptr));
        pushButton_G10->setText(QCoreApplication::translate("SeatAvailability", "G10", nullptr));
        pushButton_G11->setText(QCoreApplication::translate("SeatAvailability", "G11", nullptr));
        pushButton_G12->setText(QCoreApplication::translate("SeatAvailability", "G12", nullptr));
        pushButton_H1->setText(QCoreApplication::translate("SeatAvailability", "H1", nullptr));
        pushButton_H2->setText(QCoreApplication::translate("SeatAvailability", "H2", nullptr));
        pushButton_H3->setText(QCoreApplication::translate("SeatAvailability", "H3", nullptr));
        pushButton_H4->setText(QCoreApplication::translate("SeatAvailability", "H4", nullptr));
        pushButton_H5->setText(QCoreApplication::translate("SeatAvailability", "H5", nullptr));
        pushButton_H6->setText(QCoreApplication::translate("SeatAvailability", "H6", nullptr));
        pushButton_H7->setText(QCoreApplication::translate("SeatAvailability", "H7", nullptr));
        pushButton_H8->setText(QCoreApplication::translate("SeatAvailability", "H8", nullptr));
        pushButton_H9->setText(QCoreApplication::translate("SeatAvailability", "H9", nullptr));
        pushButton_H10->setText(QCoreApplication::translate("SeatAvailability", "H10", nullptr));
        pushButton_H11->setText(QCoreApplication::translate("SeatAvailability", "H11", nullptr));
        pushButton_H12->setText(QCoreApplication::translate("SeatAvailability", "H12", nullptr));
        pushButton->setText(QCoreApplication::translate("SeatAvailability", "Continue", nullptr));
    } // retranslateUi

};

namespace Ui {
    class SeatAvailability: public Ui_SeatAvailability {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SEATAVAILABILITY_H
